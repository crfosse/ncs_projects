#ifndef mult__h
#define mult__h

int mult(int a, int b);

#endif